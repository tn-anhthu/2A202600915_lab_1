import os
import time
from typing import Any, Callable
from openai import OpenAI

# ---------------------------------------------------------------------------
# Estimated costs per 1K OUTPUT tokens (USD) — update if pricing changes
# ---------------------------------------------------------------------------
COST_PER_1K_OUTPUT_TOKENS = {
    "gpt-4o": 0.010,
    "gpt-4o-mini": 0.0006,
}

OPENAI_MODEL = "gpt-4o"
OPENAI_MINI_MODEL = "gpt-4o-mini"


# ---------------------------------------------------------------------------
# Task 1 — Call GPT-4o
# ---------------------------------------------------------------------------
def call_openai(
    prompt: str,
    model: str = OPENAI_MODEL,
    temperature: float = 0.7,
    top_p: float = 0.9,
    max_tokens: int = 256,
) -> tuple[str, float]:
    """
    Call the OpenAI Chat Completions API and return the response text + latency.
    """
    # Initialize client (looks for OPENAI_API_KEY env variable automatically)
    client = OpenAI()
    
    start_time = time.time()
    
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,
        top_p=top_p,
        max_tokens=max_tokens,
    )
    
    latency = time.time() - start_time
    response_text = response.choices[0].message.content or ""
    
    return response_text, latency


# ---------------------------------------------------------------------------
# Task 2 — Call GPT-4o-mini
# ---------------------------------------------------------------------------
def call_openai_mini(
    prompt: str,
    temperature: float = 0.7,
    top_p: float = 0.9,
    max_tokens: int = 256,
) -> tuple[str, float]:
    """
    Call the OpenAI Chat Completions API using gpt-4o-mini and return the
    response text + latency.
    """
    return call_openai(
        prompt=prompt,
        model=OPENAI_MINI_MODEL,
        temperature=temperature,
        top_p=top_p,
        max_tokens=max_tokens,
    )


# ---------------------------------------------------------------------------
# Task 3 — Compare GPT-4o vs GPT-4o-mini
# ---------------------------------------------------------------------------
def compare_models(prompt: str) -> dict:
    """
    Call both gpt-4o and gpt-4o-mini with the same prompt and return a
    comparison dictionary.
    """
    gpt4o_response, gpt4o_latency = call_openai(prompt)
    mini_response, mini_latency = call_openai_mini(prompt)
    
    # Cost calculation formula provided in the hint:
    # Cost estimate = (len(response.split()) / 0.75) / 1000 * COST_PER_1K_OUTPUT_TOKENS["gpt-4o"]
    estimated_tokens = len(gpt4o_response.split()) / 0.75
    gpt4o_cost_estimate = (estimated_tokens / 1000) * COST_PER_1K_OUTPUT_TOKENS["gpt-4o"]
    
    return {
        "gpt4o_response": gpt4o_response,
        "mini_response": mini_response,
        "gpt4o_latency": gpt4o_latency,
        "mini_latency": mini_latency,
        "gpt4o_cost_estimate": gpt4o_cost_estimate,
    }


# ---------------------------------------------------------------------------
# Task 4 — Streaming chatbot with conversation history
# ---------------------------------------------------------------------------
def streaming_chatbot() -> None:
    """
    Run an interactive streaming chatbot in the terminal.
    Maintains the last 3 conversation turns in history.
    """
    client = OpenAI()
    history = []
    
    while True:
        try:
            user_input = input("\nYou: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nExiting chatbot...")
            break
            
        if user_input.lower() in ["quit", "exit"]:
            print("Goodbye!")
            break
            
        if not user_input:
            continue
            
        # Append user turn to ongoing history
        history.append({"role": "user", "content": user_input})
        
        # Enforce keeping ONLY the last 3 turns
        # 3 turns = 3 user requests + 3 assistant responses (up to 6 elements)
        # Note: If history length is strictly limited to 3 items, adjust context window slice.
        # But standard definition of 'turns' usually implies 3 message pairs.
        # To be absolutely safe with context trimming matching standard lists:
        active_history = history[-6:] 
        
        print("Assistant: ", end="", flush=True)
        
        stream = client.chat.completions.create(
            model=OPENAI_MINI_MODEL,
            messages=active_history,
            stream=True
        )
        
        assistant_reply = ""
        for chunk in stream:
            delta = chunk.choices[0].delta.content or ""
            print(delta, end="", flush=True)
            assistant_reply += delta
            
        print() # New line after stream ends
        
        # Append assistant response to memory loop
        history.append({"role": "assistant", "content": assistant_reply})


# ---------------------------------------------------------------------------
# Bonus Task A — Retry with exponential backoff
# ---------------------------------------------------------------------------
def retry_with_backoff(
    fn: Callable,
    max_retries: int = 3,
    base_delay: float = 0.1,
) -> Any:
    """
    Call fn(). If it raises an exception, retry up to max_retries times
    with exponential backoff (base_delay * 2^attempt).
    """
    attempt = 0
    while True:
        try:
            return fn()
        except Exception as e:
            if attempt >= max_retries:
                raise e
            
            delay = base_delay * (2 ** attempt)
            time.sleep(delay)
            attempt += 1


# ---------------------------------------------------------------------------
# Bonus Task B — Batch compare
# ---------------------------------------------------------------------------
def batch_compare(prompts: list[str]) -> list[dict]:
    """
    Run compare_models on each prompt in the list.
    """
    results = []
    for prompt in prompts:
        res_dict = compare_models(prompt)
        res_dict["prompt"] = prompt
        results.append(res_dict)
    return results


# ---------------------------------------------------------------------------
# Bonus Task C — Format comparison table
# ---------------------------------------------------------------------------
def format_comparison_table(results: list[dict]) -> str:
    """
    Format a list of compare_models results as a readable text table.
    Truncate long text to 40 characters for clean terminal visibility.
    """
    def truncate(text: str, max_len: int = 40) -> str:
        text_clean = text.replace("\n", " ")
        if len(text_clean) > max_len:
            return text_clean[:max_len-3] + "..."
        return text_clean

    # Set up column headers matching the unit test requirements
    headers = ["Prompt", "GPT-4o Response", "Mini Response", "GPT-4o Latency", "Mini Latency"]
    
    # Header Row
    table_lines = []
    header_str = f"{headers[0]:<40} | {headers[1]:<40} | {headers[2]:<40} | {headers[3]:<14} | {headers[4]:<14}"
    table_lines.append(header_str)
    table_lines.append("-" * len(header_str))
    
    # Data Rows
    for res in results:
        p = truncate(res.get("prompt", ""))
        g4o = truncate(res.get("gpt4o_response", ""))
        mini = truncate(res.get("mini_response", ""))
        g4o_lat = f"{res.get('gpt4o_latency', 0.0):.3f}s"
        mini_lat = f"{res.get('mini_latency', 0.0):.3f}s"
        
        row_str = f"{p:<40} | {g4o:<40} | {mini:<40} | {g4o_lat:<14} | {mini_lat:<14}"
        table_lines.append(row_str)
        
    return "\n".join(table_lines)


# ---------------------------------------------------------------------------
# Entry point for manual testing
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    test_prompt = "Explain the difference between temperature and top_p in one sentence."
    print("=== Comparing models ===")
    result = compare_models(test_prompt)
    for key, value in result.items():
        print(f"{key}: {value}")

    print("\n=== Starting chatbot (type 'quit' to exit) ===")
    streaming_chatbot()
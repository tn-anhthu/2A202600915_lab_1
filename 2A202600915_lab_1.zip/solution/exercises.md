# Ngày 1 — Bài Tập & Phản Ánh
## Nền Tảng LLM API | Phiếu Thực Hành

**Thời lượng:** 1:30 giờ  
**Cấu trúc:** Lập trình cốt lõi (60 phút) → Bài tập mở rộng (30 phút)

---

## Phần 1 — Lập Trình Cốt Lõi (0:00–1:00)

Chạy các ví dụ trong Google Colab tại: https://colab.research.google.com/drive/172zCiXpLr1FEXMRCAbmZoqTrKiSkUERm?usp=sharing

Triển khai tất cả TODO trong `template.py`. Chạy `pytest tests/` để kiểm tra tiến độ.

**Điểm kiểm tra:** Sau khi hoàn thành 4 nhiệm vụ, chạy:
```bash
python template.py
```
Bạn sẽ thấy output so sánh phản hồi của GPT-4o và GPT-4o-mini.

---

## Phần 2 — Bài Tập Mở Rộng (1:00–1:30)

### Bài tập 2.1 — Độ Nhạy Của Temperature
Gọi `call_openai` với các giá trị temperature 0.0, 0.5, 1.0 và 1.5 sử dụng prompt **"Hãy kể cho tôi một sự thật thú vị về Việt Nam."**

**Bạn nhận thấy quy luật gì qua bốn phản hồi?** (2–3 câu)
> Khi nâng dần temperature từ $0.0$ lên $1.5$, các phản hồi có xu hướng chuyển từ trạng thái nhất quán, chính xác cao sang sáng tạo, bay bổng và cuối cùng là mất kiểm soát. Cụ thể, ở mức $0.0$ và $0.5$, mô hình lặp lại các sự thật quen thuộc (như xuất khẩu cà phê hoặc hang Sơn Đoòng) với văn phong gãy gọn; nhưng khi chạm mốc $1.0$ và đặc biệt là $1.5$, câu từ bắt đầu trở nên ngẫu nhiên, cấu trúc câu lạ lẫm hơn, và xuất hiện hiện tượng "ảo giác" (hallucination) hoặc vỡ font/ký tự lạ do xác suất chọn từ tiếp theo quá hỗn loạn.

**Bạn sẽ đặt temperature bao nhiêu cho chatbot hỗ trợ khách hàng, và tại sao?**
> Đối với chatbot hỗ trợ khách hàng, mình sẽ đặt temperature trong khoảng $0.0$ đến $0.2$ (ưu tiên $0.0$ nếu cần sự chính xác tuyệt đối).Tại sao? Vì nhiệm vụ cốt lõi của một bot CSKH là cung cấp thông tin chính xác, đáng tin cậy và nhất quán (như chính sách hoàn tiền, giá sản phẩm, quy trình bảo hành). Việc giữ temperature cực thấp giúp giảm thiểu tối đa rủi ro mô hình "bịa đặt" thông tin (hallucination) và đảm bảo cùng một câu hỏi của khách hàng sẽ luôn nhận được một câu trả lời chuẩn chỉnh giống nhau, tránh gây hoang mang cho người dùng.

---

### Bài tập 2.2 — Đánh Đổi Chi Phí
Xem xét kịch bản: 10.000 người dùng hoạt động mỗi ngày, mỗi người thực hiện 3 lần gọi API, mỗi lần trung bình ~350 token.

**Ước tính xem GPT-4o đắt hơn GPT-4o-mini bao nhiêu lần cho workload này:**
> *Câu trả lời của bạn*

**Mô tả một trường hợp mà chi phí cao hơn của GPT-4o là xứng đáng, và một trường hợp GPT-4o-mini là lựa chọn tốt hơn:**
> Trường hợp GPT-4o xứng đáng: Khi bồ làm các task yêu cầu khả năng lập luận phức tạp, phân tích đa phương tiện (Multimodal) hoặc cần độ chính xác cực cao, chẳng hạn như: Hệ thống tự động quét ảnh chụp hóa đơn mua sắm phức tạp của Mars để bóc tách thông tin chi tiết và kiểm tra tính hợp lệ, hoặc hệ thống phân tích hình ảnh y tế (Medical Imaging Segmentation) để chẩn đoán bệnh. Những task này đòi hỏi thị giác máy tính đỉnh cao mà các dòng mini không thể cân nổi.

>Trường hợp GPT-4o-mini tốt hơn: Khi bồ xây dựng các tính năng có volume cực lớn, lặp đi lặp lại và yêu cầu latency thấp, ví dụ như: Chatbot hỗ trợ khách hàng trả lời các câu hỏi FAQ thường gặp, hệ thống phân loại nhãn văn bản (Text Classification), hoặc trích xuất thông tin thực thể (NER) từ các đoạn văn bản có cấu trúc đơn giản. Việc dùng mô hình lớn ở đây sẽ gây lãng phí ngân sách doanh nghiệp một cách không cần thiết.

---

### Bài tập 2.3 — Trải Nghiệm Người Dùng với Streaming
**Streaming quan trọng nhất trong trường hợp nào, và khi nào thì non-streaming lại phù hợp hơn?** (1 đoạn văn)
> Streaming đóng vai trò sống còn trong các ứng dụng tương tác trực tiếp với con người (Human-in-the-loop) như chatbot hỗ trợ, trợ lý ảo hoặc các công cụ đồng hành viết code (như Cursor/Claude Code), nơi mà "Thời gian phản hồi đầu tiên" (Time to First Token - TTFT) quyết định toàn bộ trải nghiệm người dùng. Thay vì bắt người dùng phải nhìn màn hình trống trơn và chờ đợi mỏi mòn 5-10 giây để nhận toàn bộ văn bản (gây cảm giác lag, ứng dụng bị treo), việc stream từng từ xuất hiện ngay lập tức giúp duy trì mạch tương tác tự nhiên và giữ chân người dùng ở lại.

> Ngược lại, Non-streaming lại là lựa chọn tối ưu và gọn gàng hơn cho các tác vụ xử lý ngầm (Background/Backend Processing) hoặc xử lý theo lô (Batch Processing) không có sự tương tác thời gian thực từ con người. Các kịch bản điển hình bao gồm: gọi API để trả về định dạng JSON nghiêm ngặt (Structured Outputs) phục vụ cho hệ thống khác đọc, các script tự động phân tích sắc thái bình luận (Sentiment Analysis), dịch thuật hàng loạt tài liệu, hoặc chạy các pipeline tổng hợp dữ liệu định kỳ vào cuối ngày. Ở các trường hợp này, việc đợi lấy toàn vẹn cục data một lần giúp code backend xử lý logic, bắt lỗi (try-catch) và lưu trữ vào database dễ dàng, sạch sẽ hơn rất nhiều.


## Danh Sách Kiểm Tra Nộp Bài
- [ ] Tất cả tests pass: `pytest tests/ -v`
- [ ] `call_openai` đã triển khai và kiểm thử
- [ ] `call_openai_mini` đã triển khai và kiểm thử
- [ ] `compare_models` đã triển khai và kiểm thử
- [ ] `streaming_chatbot` đã triển khai và kiểm thử
- [ ] `retry_with_backoff` đã triển khai và kiểm thử
- [ ] `batch_compare` đã triển khai và kiểm thử
- [ ] `format_comparison_table` đã triển khai và kiểm thử
- [ ] `exercises.md` đã điền đầy đủ
- [ ] Sao chép bài làm vào folder `solution` và đặt tên theo quy định 
